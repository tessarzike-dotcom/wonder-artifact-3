BEYOND FIRST IMPRESSIONS — ARTIFACT 3

Files:
- index.html: self-contained interactive HTML feature

Publishing:
1. Upload index.html to a web host or your institution's supported course file area.
2. If your Brightspace instance supports uploading HTML files and opening them in a browser, upload this file and test the resulting link.
3. For a Brightspace Content package, zip the index.html file and upload the ZIP only if your course supports package extraction/import. Some Brightspace instances do not host HTML files as live web pages; in that case, use an approved web host and post the public URL.

Features include clickable navigation, perspective switching, Keep/Revise/Reject feedback, evidence reveal prompts, a quiz, a completion checklist, text-to-speech, student note fields, and linked first-person nonfiction sources.

External nonfiction sources are linked from AboutFace. Students should read the source pages directly; the activity summarizes their focus and does not speak for every person with a facial difference.
